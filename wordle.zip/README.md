# Wordle Game!!
## This is a simple wordle game made using python and pygame.
Using Flask to create a web app for the game.
Random to generate random words.

## Process:
1. Start game.
2. Guess the word, you have 6 chances to guess.
3. Win the game!