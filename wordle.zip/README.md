# Wordle Game!!
## This is a simple wordle game made using Flask python.
Using Flask to create a web app for the game.
Random to generate random words.
  
This game is made in programming4 class KOSEN-KMITL.
## Process:
1. Start game.
2. Guess the word, you have 6 chances to guess.
3. Win the game!